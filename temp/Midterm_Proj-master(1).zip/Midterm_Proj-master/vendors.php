
<html>
<body>

</h1>
   <a href="admin.php">Return to Admin Page</a>
    <form action="vendoradd.php" method="post">
    <p>Vendor Name: <input type="text" name="vendor" /></p>
   <p>Vendor Phone Num: <input type="text" name="number" /></p>
    <p>Sales Rep: <input type="text" name="SR" /></p>
    <p>Payment methods: <textarea name="PM" rows="4" cols="50"></textarea></p>
    <p>Vendor Preference: <textarea name="VP" rows="4" cols="50"></textarea></p>
    <p>Stock update: <textarea name="SU" rows="4" cols="50"></textarea>/Month</p>	
		
    
      <p><input name="submit" value="Submit" type="submit"/></p>

</body>
</html>



