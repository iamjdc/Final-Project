
<html>
<body>

</h1>
   <a href="admin.php">Return to Admin Page</a>
   

 <form action="funcsearch.php?search=PaymentMethod" method="post">
    <p>Payment methods: <textarea name="PM" rows="4" cols="50"></textarea></p>
  
      <p><input name="submit" value="Submit" type="submit"/></p>
</form>
    <form name="fun1" action="funcsearch.php?search=VendorPref" method="post">
        <p>Vendor Preference: <textarea name="VP" rows="4" cols="50"></textarea></p>
  
      <p><input name="submit2" value="Submit" type="submit"/></p>
</form>
    <form name="fun2" action="funcsearch.php?search=StockUpdate" method="post">
    <p>Stock update: <textarea name="SU" rows="4" cols="50"></textarea> per Month</p>
  
      <p><input name="submit3" value="Submit" type="submit"/></p>
</form>

	




</body>
</html>



