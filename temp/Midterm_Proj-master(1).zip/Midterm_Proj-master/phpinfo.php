<?php

phpinfo();

echo '<div>hahaha</div'; 

?>
